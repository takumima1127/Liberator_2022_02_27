#pragma once
#include <memory>
#include <vector>
#include "Graphics/Graphics.h"
#include "UI.h"

class WindowManager
{
private:
    inline static std::unique_ptr<WindowManager> instance = nullptr;

public:
    WindowManager();
    ~WindowManager();

    static WindowManager& Instance()
    {
        static WindowManager instance;
        return instance;
    }

    //�Z�b�g
    void Set(const wchar_t* window_name, XMFLOAT2 position, XMFLOAT2 size, XMFLOAT4 color = UI_Window::color_array.at(UI_Window::WindowColor::Default));

    //�X�V����
    void Update(float elapsedTime);

    //�`�揈��
    void Render(ID3D11DeviceContext* dc, Font* font);

    //�폜
    void Remove(UI_Window* window);

    //�S�폜
    void Clear();

public:
    //�Q�b�^�[
    UI_Window* GetWindow(const wchar_t* window_name);

private:
    //�萔
    static const  int EXIST_TIMER_MAX = 100;

private:
    std::vector<UI_Window*> window_array;//TODO array�ɖ����ύX
    std::vector<UI_Window*> removes;//�폜�p�R���e�i

    std::unique_ptr<UI_Window> window;
};
#pragma once
#include "Graphics/Sprite.h"
#include "Graphics/Texture.h"
#include "Graphics/Font.h"
#include <map>
#include "Input/Input.h"
#include "Input/GamePad.h"

using namespace DirectX;

//UI�N���X
class UI_Sprite
{
public:
	UI_Sprite();//�e�N�X�`����
	UI_Sprite(const wchar_t* filename);
	UI_Sprite(const wchar_t* filename, XMFLOAT2 position, XMFLOAT2 size, XMFLOAT2 scroll, float angle, XMFLOAT4 color);
	~UI_Sprite();

	// ������
	//void Initialize();
	//void Initialize(XMFLOAT2 position, float width, float height, XMFLOAT2 scroll, float angle, XMFLOAT4 color);

	// �X�V����
	void Update(float elapsedTime);

	//�`��
	void Render(ID3D11DeviceContext* dc);
	void Render(std::shared_ptr<Texture> tex, ID3D11DeviceContext* dc);
	void Render(ID3D11DeviceContext* dc, XMFLOAT2 position,XMFLOAT2 size, XMFLOAT2 scroll, float angle, XMFLOAT4 color);//�����͂���Ȃ��H
	void Render(std::shared_ptr<Texture> tex, ID3D11DeviceContext* dc, XMFLOAT2 position, XMFLOAT2 size, XMFLOAT2 scroll, float angle, XMFLOAT4 color);//�����͂���Ȃ��H

private:
	std::shared_ptr<Sprite> sprite = nullptr;
	std::shared_ptr<Texture> texture = nullptr;

	//�����o�ϐ��i���N���X�ړ��H�j
	XMFLOAT2 position;
	XMFLOAT2 size;
	XMFLOAT2 scroll;
	float angle;
	XMFLOAT4 color;

public:
	//�Z�b�^�[
	void SetPosition(const DirectX::XMFLOAT2& position) { this->position = position; }
	void SetScale(const DirectX::XMFLOAT2& size) { this->size = size; }
	void SetScroll(const DirectX::XMFLOAT2& scroll) { this->scroll = scroll; }
	void SetAngle(const float& angle) { this->angle = angle; }
	void SetColor(const DirectX::XMFLOAT4& color) { this->color = color; }
	//void SetTexture(botton_texture);

	//�Q�b�^�[
	const DirectX::XMFLOAT2 GetPositon() const { return position; }
	const DirectX::XMFLOAT2 GetScale() const { return size; }
	const DirectX::XMFLOAT2 GetScroll() const { return scroll; }
	const float GetAngle() const { return angle; }
	const DirectX::XMFLOAT4 GetColor() const { return color; }
};

//���b�Z�[�W�N���X
class UI_Message
{
public:
	UI_Message(const wchar_t* message, XMFLOAT2 position, float size, bool centering = false);
	~UI_Message();

	// �X�V����
	void Update(float elapsedTime);

	//�`��
	void Render(ID3D11DeviceContext* dc, Font* font);

private:
	DirectX::XMFLOAT2 position;
	float size;
	const wchar_t* message;
	bool centering;//�����������s�����ǂ���

public:
	const DirectX::XMFLOAT2 GetPositon() const { return position; }
	const float GetSize() const { return size; }
	const wchar_t* GetThisMessage() const { return message; }
};

//�{�^���N���X
class UI_Button
{
public:
	UI_Button(const wchar_t* message, XMFLOAT2 position, XMFLOAT2 size);//�e�N�X�`����
	~UI_Button();

	// �X�V����
	void Update(float elapsedTime);

	//�`��
	void Render(ID3D11DeviceContext* dc, Font* font);

	//�����ꂽ���ɌĂ΂�鏈��
	void Push();
	void Push(void* func);//����

private:
	std::shared_ptr<Sprite> select_button_sprite = nullptr;//�{�^���p�X�v���C�g
	std::shared_ptr<Texture> texture = nullptr;

	//�����o�ϐ��i���N���X�ړ��H�j
	XMFLOAT2 position;
	XMFLOAT2 size;
	XMFLOAT2 scroll;
	float angle;
	XMFLOAT4 color;
	float color_coefficient;//�F�����p�W��
	bool color_add_flag;//�F�����p�t���O

	bool is_select = false;//�I������Ă��邩�ǂ���
	bool is_push = false;//������Ė������

	const wchar_t* message;

private:
	const float NAME_OFFSET_X = 16.0f;
	const float NAME_OFFSET_Y = 7.0f;
	const float NAME_SPRITE_WIDTH = 64.0f;
	const float NAME_SPRITE_HEIGHT = 32.0f;
	const DirectX::XMFLOAT4 DEFAULT_COLOR = DirectX::XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f);//��I�����̐F
	const DirectX::XMFLOAT4 SELECT_COLOR = DirectX::XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);//�I�����̐F

public:
	//�Z�b�^�[
	void SetPosition(const DirectX::XMFLOAT2& position) { this->position = position; }
	void SetScale(const DirectX::XMFLOAT2& size) { this->size = size; }
	void SetScroll(const DirectX::XMFLOAT2& scroll) { this->scroll = scroll; }
	void SetAngle(const float& angle) { this->angle = angle; }
	void SetColor(const DirectX::XMFLOAT4& color) { this->color = color; }
	void SetSelectFlag(const bool is_select) { this->is_select = is_select; }

	//�Q�b�^�[
	const DirectX::XMFLOAT2 GetPositon() const { return position; }
	const DirectX::XMFLOAT2 GetScale() const { return size; }
	const DirectX::XMFLOAT2 GetScroll() const { return scroll; }
	const float GetAngle() const { return angle; }
	const DirectX::XMFLOAT4 GetColor() const { return color; }

	bool GetIsPush() { return is_push; }
};

//�E�C���h�E�N���X
class UI_Window
{
public:
	//�萔
	enum class WindowColor
	{
		Default,
		NameWindow,
		Black,
		White,
		Red,
		Green,
		Blue,
	};
	inline static std::map<WindowColor, DirectX::XMFLOAT4> color_array =
	{
		{WindowColor::Default, DirectX::XMFLOAT4(.0f, .0f, .0f, 0.7f)},
		{WindowColor::NameWindow, DirectX::XMFLOAT4(.0f, 1.0f, 1.0f, 0.8f)},
		{WindowColor::Black, DirectX::XMFLOAT4(1.0f, 1.0f, 1.0f, 0.7f)},
		{WindowColor::White, DirectX::XMFLOAT4(1.0f, 1.0f, 1.0f, 0.7f)},
		{WindowColor::Red, DirectX::XMFLOAT4(1.0f, .0f, .0f, 0.7f)},
		{WindowColor::Green, DirectX::XMFLOAT4(.0f, 1.0f, .0f, 0.7f)},
		{WindowColor::Blue, DirectX::XMFLOAT4(.0f, .0f, 1.0f, 0.7f)},
	};


public:
	UI_Window();
	UI_Window(const wchar_t* window_name);//�e�N�X�`����
	UI_Window(XMFLOAT2 position, XMFLOAT2 size, XMFLOAT2 scroll, float angle, XMFLOAT4 color = color_array.at(WindowColor::Default));
	UI_Window(const wchar_t* window_name, XMFLOAT2 position, XMFLOAT2 size, XMFLOAT4 color = color_array.at(WindowColor::Default));
	~UI_Window();

	// ������
	//void Initialize();
	//void Initialize(XMFLOAT2 position, float width, float height, XMFLOAT2 scroll, float angle, XMFLOAT4 color);

	// �X�V����
	void Update(float elapsedTime);

	//�`��
	void Render(ID3D11DeviceContext* dc, Font* font);

	//�㏈��
	void Clear();

protected:
	std::shared_ptr<Sprite> window_sprite = nullptr;//�E�B���h�E�p�X�v���C�g
	std::shared_ptr<Sprite> window_name_sprite = nullptr;//�E�B���h�E���\���p�X�v���C�g
	std::shared_ptr<Texture> texture = nullptr;

	//�����o�ϐ��i���N���X�ړ��H�j
	XMFLOAT2 position;
	XMFLOAT2 size;
	XMFLOAT2 scroll;
	float angle;
	XMFLOAT4 color;
	const wchar_t* window_name;

	std::vector<UI_Button*> button_array;
	std::unique_ptr<UI_Button> button = nullptr;

	//struct Message
	//{
	//	const wchar_t* string;
	//	DirectX::XMFLOAT2 position = DirectX::XMFLOAT2(.0f, .0f);
	//	float size;
	//};

	//std::vector<const wchar_t*> message_array;
	std::vector<UI_Message*> message_array;
	std::unique_ptr<UI_Message> message = nullptr;
    
	//�{�^���֘A
	int select_state = 0;//�ǂ̃{�^�����I������Ă��邩
	float select_interval = .0f;//�J�[�\���ړ��̊Ԋu


protected:
	//�萔
	const float NAME_SPRITE_HEIGHT = 32.0f;
	const DirectX::XMFLOAT4 NAME_SPRITE_COLOR = DirectX::XMFLOAT4(.0f, 1.0f, 1.0f, 0.8f);
	const float NAME_OFFSET_X = 16.0f;
	const float NAME_OFFSET_Y = 7.0f;
	const float SELECT_INTERVAL_MAX = 0.2f;//�{�^���J�[�\���ړ��̊Ԋu

	const float DEFAULT_FONT_SIZE = 0.7f;

public:
	//�Z�b�^�[
	void SetPosition(const DirectX::XMFLOAT2& position) { this->position = position; }
	void SetScale(const DirectX::XMFLOAT2& size) { this->size = size; }
	void SetScroll(const DirectX::XMFLOAT2& scroll) { this->scroll = scroll; }
	void SetAngle(const float& angle) { this->angle = angle; }
	void SetColor(const DirectX::XMFLOAT4& color) { this->color = color; }
	void SetWindowName(const wchar_t* window_name) { this->window_name = window_name; }

	void AddButton(const wchar_t* message, XMFLOAT2 position, XMFLOAT2 size);//�{�^���ǉ�
	void AddMessage(const wchar_t* string, XMFLOAT2 position, float scale, bool centering = false);//���b�Z�[�W�ǉ�

	//�Q�b�^�[
	const DirectX::XMFLOAT2 GetPositon() const { return position; }
	const DirectX::XMFLOAT2 GetScale() const { return size; }
	const DirectX::XMFLOAT2 GetScroll() const { return scroll; }
	const float GetAngle() const { return angle; }
	const DirectX::XMFLOAT4 GetColor() const { return color; }
	const wchar_t* GetWindowName() const { return window_name; }
	const float GetDefaultFontSize()const { return DEFAULT_FONT_SIZE; }
	const UI_Message* GetUIMessage(const wchar_t* message);

	bool GetIsPush(int button_id);//�w�肵���{�^����������Ă��邩�̃t���O��Ԃ�
};
#include "EnemyMutant.h"

void EnemyMutant::SetRandomTargetPosition()
{
}

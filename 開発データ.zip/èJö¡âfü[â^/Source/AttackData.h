#pragma once
#include <DirectXMath.h>
#include <map>
#include <vector>
#include <memory>
#include <string>

class AttackData
{
public:
	AttackData() {};
	~AttackData() {};
	void Initialize(float cancel_time, int hit_max, float begin_trajectory_time, float end_trajectory_time);
	void CollisionFlagInit();//����t���O������
	enum class AttackCollisionFlag
	{
		Before,
		True,
		Affter
	};

private:
	struct AttackCollisionData
	{
		int damage = 0;
		float begin_collision_time = .0f;
		float end_collision_time = .0f;
		AttackCollisionFlag collision_flag = AttackCollisionFlag::Before;
	};

public:
	//�Q�b�^�[
	const int GetDamage(int iterator) const { return collision_data_array[iterator].damage; }
	const float GetBeginCollisionTime(int iterator) const { return collision_data_array[iterator].begin_collision_time; }
	const float GetEndCollisionTime(int iterator) const { return collision_data_array[iterator].end_collision_time; }
	const AttackCollisionFlag GetCollisionFlag(int iterator) const { return collision_data_array[iterator].collision_flag; }
	const int GetHitMax() const { return hit_max; }
	const float GetCancelTime() const { return cancel_time; }
	const float GetBeginTrajectoryTime() const { return begin_trajectory_time; }
	const float GetEndTrajectoryTime() const { return end_trajectory_time; }

	std::vector<AttackCollisionData> GetCollisionDataArray() { return collision_data_array; }
	void SetCollisionDataArraySize(int size);

	//�Z�b�^�[
	void SetCancelTime(float cancel_time) { this->cancel_time = cancel_time; }
	void SetHitMax(int hit_max) { this->hit_max = hit_max; }
	void SetBeginTrajectoryTime(float begin_trajectory_time) { this->begin_trajectory_time = begin_trajectory_time; }
	void SetEndTrajectoryTime(float end_trajectory_time) { this->end_trajectory_time = end_trajectory_time; }

	void SetCollisionFlag(int iterator, AttackCollisionFlag flag) { collision_data_array[iterator].collision_flag = flag; }
	void SetCollisionData(int iterator, int damage, float begin_collision_time, float end_collision_time);

private:
	//�����o�ϐ�
	float cancel_time = .0f;
	int hit_max = 0;
	float begin_trajectory_time = .0f;
	float end_trajectory_time = .0f;
	std::vector<AttackCollisionData> collision_data_array;
};

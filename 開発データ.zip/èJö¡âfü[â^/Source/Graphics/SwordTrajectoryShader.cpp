//#include "Misc.h"
//#include "Graphics/SwordTrajectoryShader.h"
//#include "Graphics/Graphics.h"
//#include "Light.h"
//#include "Vector.h"
//#include "SwordTrajectoryRenderer.h"
//#include "SwordTrajectory.h"
//
//SwordTrajectoryShader::SwordTrajectoryShader(ID3D11Device* device)
//{
//	////���C�g������
//	//Light::Init();
//
//	// ���_�V�F�[�_�[
//	{
//		// �t�@�C�����J��
//		FILE* fp = nullptr;
//		fopen_s(&fp, "Shader\\SwordTrajectoryShaderVS.cso", "rb");
//		_ASSERT_EXPR_A(fp, "CSO File not found");
//
//		// �t�@�C���̃T�C�Y�����߂�
//		fseek(fp, 0, SEEK_END);
//		long csoSize = ftell(fp);
//		fseek(fp, 0, SEEK_SET);
//
//		// ��������ɒ��_�V�F�[�_�[�f�[�^���i�[����̈��p�ӂ���
//		std::unique_ptr<u_char[]> csoData = std::make_unique<u_char[]>(csoSize);
//		fread(csoData.get(), csoSize, 1, fp);
//		fclose(fp);
//
//		// ���_�V�F�[�_�[����
//		HRESULT hr = device->CreateVertexShader(csoData.get(), csoSize, nullptr, vertexShader.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//
//		// ���̓��C�A�E�g
//		D3D11_INPUT_ELEMENT_DESC inputElementDesc[] =
//		{
//			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT,    0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,       0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		};
//		hr = device->CreateInputLayout(inputElementDesc, ARRAYSIZE(inputElementDesc), csoData.get(), csoSize, inputLayout.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �s�N�Z���V�F�[�_�[
//	{
//		// �t�@�C�����J��
//		FILE* fp = nullptr;
//		fopen_s(&fp, "Shader\\SwordTrajectoryShaderPS.cso", "rb");
//		_ASSERT_EXPR_A(fp, "CSO File not found");
//
//		// �t�@�C���̃T�C�Y�����߂�
//		fseek(fp, 0, SEEK_END);
//		long csoSize = ftell(fp);
//		fseek(fp, 0, SEEK_SET);
//
//		// ��������ɒ��_�V�F�[�_�[�f�[�^���i�[����̈��p�ӂ���
//		std::unique_ptr<u_char[]> csoData = std::make_unique<u_char[]>(csoSize);
//		fread(csoData.get(), csoSize, 1, fp);
//		fclose(fp);
//
//		// �s�N�Z���V�F�[�_�[����
//		HRESULT hr = device->CreatePixelShader(csoData.get(), csoSize, nullptr, pixelShader.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �萔�o�b�t�@
//	{
//		D3D11_BUFFER_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.Usage = D3D11_USAGE_DEFAULT;
//		desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
//		desc.CPUAccessFlags = 0;
//		desc.MiscFlags = 0;
//		desc.ByteWidth = sizeof(ConstantBuffer);
//		desc.StructureByteStride = 0;
//
//		HRESULT hr = device->CreateBuffer(&desc, 0, constantBuffer.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �u�����h�X�e�[�g
//	{
//		D3D11_BLEND_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.AlphaToCoverageEnable = false;
//		desc.IndependentBlendEnable = false;
//		desc.RenderTarget[0].BlendEnable = true;
//		desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
//		desc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
//		desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
//		desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
//		desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
//		desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
//		desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
//
//		HRESULT hr = device->CreateBlendState(&desc, blendState.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �[�x�X�e���V���X�e�[�g
//	{
//		D3D11_DEPTH_STENCIL_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.DepthEnable = true;
//		desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
//		desc.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
//
//		HRESULT hr = device->CreateDepthStencilState(&desc, depthStencilState.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// ���X�^���C�U�[�X�e�[�g
//	{
//		D3D11_RASTERIZER_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.FrontCounterClockwise = false;
//		desc.DepthBias = 0;
//		desc.DepthBiasClamp = 0;
//		desc.SlopeScaledDepthBias = 0;
//		desc.DepthClipEnable = true;
//		desc.ScissorEnable = false;
//		desc.MultisampleEnable = true;
//		desc.FillMode = D3D11_FILL_SOLID;
//		desc.CullMode = D3D11_CULL_NONE;
//		desc.AntialiasedLineEnable = false;
//
//		HRESULT hr = device->CreateRasterizerState(&desc, rasterizerState.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �T���v���X�e�[�g
//	{
//		D3D11_SAMPLER_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.MipLODBias = 0.0f;
//		desc.MaxAnisotropy = 1;
//		desc.ComparisonFunc = D3D11_COMPARISON_NEVER;
//		desc.MinLOD = -FLT_MAX;
//		desc.MaxLOD = FLT_MAX;
//		desc.BorderColor[0] = 1.0f;
//		desc.BorderColor[1] = 1.0f;
//		desc.BorderColor[2] = 1.0f;
//		desc.BorderColor[3] = 1.0f;
//		desc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
//		desc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
//		desc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
//		desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
//
//		HRESULT hr = device->CreateSamplerState(&desc, samplerState.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	//�e�N�X�`���H
//}
//
//// �`��J�n
//void SwordTrajectoryShader::Begin(ID3D11DeviceContext* dc, const RenderContext& rc)
//{
//	Graphics& graphics = Graphics::Instance();
//
//	dc->VSSetShader(vertexShader.Get(), nullptr, 0);
//	dc->PSSetShader(pixelShader.Get(), nullptr, 0);
//	dc->IASetInputLayout(inputLayout.Get());
//
//	ID3D11Buffer* constantBuffers[] =
//	{
//		constantBuffer.Get(),
//	};
//	dc->VSSetConstantBuffers(0, ARRAYSIZE(constantBuffers), constantBuffers);
//	dc->PSSetConstantBuffers(0, ARRAYSIZE(constantBuffers), constantBuffers);
//
//	// �r���[�|�[�g�̐ݒ�
//	graphics.SetViewPort(graphics.GetScreenWidth(), graphics.GetScreenHeight());
//
//	//�V���h�E�}�b�v�ݒ�
//
//	const float blend_factor[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
//	dc->OMSetBlendState(blendState.Get(), blend_factor, 0xFFFFFFFF);
//	dc->OMSetDepthStencilState(depthStencilState.Get(), 1);
//	dc->RSSetState(rasterizerState.Get());
//	dc->PSSetSamplers(0, 1, samplerState.GetAddressOf());
//
//	// �V�[���p�萔�o�b�t�@�X�V
//	ConstantBuffer cb;
//
//	DirectX::XMMATRIX V = DirectX::XMLoadFloat4x4(&rc.view);
//	DirectX::XMMATRIX P = DirectX::XMLoadFloat4x4(&rc.projection);
//	
//	DirectX::XMStoreFloat4x4(&cb.viewProjection, V * P);
//
//	dc->UpdateSubresource(constantBuffer.Get(), 0, 0, &cb, 0, 0);
//}
//
////// �`��(������uique�|�C���^�ɕύX)
////void CharacterShader::Draw(ID3D11DeviceContext* dc, const std::unique_ptr<Model> model, float dissolveThreshold)
////{
////	CbSubset2 cbSubset2;
////	cbSubset2.DissolveThreshold = dissolveThreshold;
////	dc->UpdateSubresource(subsetConstantBuffer2.Get(), 0, 0, &cbSubset2, 0, 0);
////
////	const ModelResource* resource = model->GetResource();
////	const std::vector<Model::Node>& nodes = model->GetNodes();
////
////	for (const ModelResource::Mesh& mesh : resource->GetMeshes())
////	{
////		// ���b�V���p�萔�o�b�t�@�X�V
////		CbMesh cbMesh;
////		::memset(&cbMesh, 0, sizeof(cbMesh));
////		if (mesh.nodeIndices.size() > 0)
////		{
////			for (size_t i = 0; i < mesh.nodeIndices.size(); ++i)
////			{
////				DirectX::XMMATRIX worldTransform = DirectX::XMLoadFloat4x4(&nodes.at(mesh.nodeIndices.at(i)).worldTransform);
////				DirectX::XMMATRIX offsetTransform = DirectX::XMLoadFloat4x4(&mesh.offsetTransforms.at(i));
////				DirectX::XMMATRIX boneTransform = offsetTransform * worldTransform;
////				DirectX::XMStoreFloat4x4(&cbMesh.boneTransforms[i], boneTransform);
////			}
////		}
////		else
////		{
////			cbMesh.boneTransforms[0] = nodes.at(mesh.nodeIndex).worldTransform;
////		}
////		dc->UpdateSubresource(meshConstantBuffer.Get(), 0, 0, &cbMesh, 0, 0);
////
////		UINT stride = sizeof(ModelResource::Vertex);
////		UINT offset = 0;
////		dc->IASetVertexBuffers(0, 1, mesh.vertexBuffer.GetAddressOf(), &stride, &offset);
////		dc->IASetIndexBuffer(mesh.indexBuffer.Get(), DXGI_FORMAT_R32_UINT, 0);
////		dc->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
////
////		for (const ModelResource::Subset& subset : mesh.subsets)
////		{
////			CbSubset cbSubset;
////			cbSubset.materialColor = subset.material->color;
////			dc->UpdateSubresource(subsetConstantBuffer.Get(), 0, 0, &cbSubset, 0, 0);
////			dc->PSSetShaderResources(0, 1, subset.material->shaderResourceView.GetAddressOf());
////			dc->PSSetSamplers(0, 1, samplerState.GetAddressOf());
////			dc->DrawIndexed(subset.indexCount, subset.startIndex, 0);
////		}
////	}
////}
//
//// �`��
//void SwordTrajectoryShader::Draw(ID3D11DeviceContext* dc, const Model* model, float dissolveThreshold)
//{
//	ImGui::Render();
//
//	ImDrawData* drawData = ImGui::GetDrawData();
//
//	//UINT scissor_rects_count = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
//	//D3D11_RECT scissor_rects[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
//	//context->RSGetScissorRects(&scissor_rects_count, scissor_rects);
//
//	// ���_�o�b�t�@�\�z
//	if (vertexBuffer == nullptr || vertexCount < drawData->TotalVtxCount)
//	{
//		vertexBuffer.Reset();
//		vertexCount = drawData->TotalVtxCount + 5000;
//
//		D3D11_BUFFER_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.ByteWidth = sizeof(ImDrawVert) * vertexCount;
//		desc.Usage = D3D11_USAGE_DYNAMIC;
//		desc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
//		desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//		desc.MiscFlags = 0;
//		desc.StructureByteStride = sizeof(ImDrawVert);
//
//		Microsoft::WRL::ComPtr<ID3D11Device> device;
//		context->GetDevice(device.GetAddressOf());
//		HRESULT hr = device->CreateBuffer(&desc, nullptr, vertexBuffer.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �C���f�b�N�X�o�b�t�@
//	if (indexBuffer == nullptr || indexCount < drawData->TotalIdxCount)
//	{
//		indexBuffer.Reset();
//		indexCount = drawData->TotalIdxCount + 10000;
//
//		D3D11_BUFFER_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.ByteWidth = sizeof(ImDrawIdx) * indexCount;
//		desc.Usage = D3D11_USAGE_DYNAMIC;
//		desc.BindFlags = D3D11_BIND_INDEX_BUFFER;
//		desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//		desc.MiscFlags = 0;
//		desc.StructureByteStride = sizeof(ImDrawIdx);
//
//		Microsoft::WRL::ComPtr<ID3D11Device> device;
//		context->GetDevice(device.GetAddressOf());
//		HRESULT hr = device->CreateBuffer(&desc, nullptr, indexBuffer.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �萔�o�b�t�@�X�V
//	{
//		ConstantBuffer data;
//
//		float left = drawData->DisplayPos.x;
//		float right = drawData->DisplayPos.x + drawData->DisplaySize.x;
//		float top = drawData->DisplayPos.y;
//		float bottom = drawData->DisplayPos.y + drawData->DisplaySize.y;
//		data.wvp._11 = 2.0f / (right - left);
//		data.wvp._12 = 0.0f;
//		data.wvp._13 = 0.0f;
//		data.wvp._14 = 0.0f;
//		data.wvp._21 = 0.0f;
//		data.wvp._22 = 2.0f / (top - bottom);
//		data.wvp._23 = 0.0f;
//		data.wvp._24 = 0.0f;
//		data.wvp._31 = 0.0f;
//		data.wvp._32 = 0.0f;
//		data.wvp._33 = 0.5f;
//		data.wvp._34 = 0.0f;
//		data.wvp._41 = (right + left) / (left - right);
//		data.wvp._42 = (top + bottom) / (bottom - top);
//		data.wvp._43 = 0.5f;
//		data.wvp._44 = 1.0f;
//
//		context->UpdateSubresource(constantBuffer.Get(), 0, 0, &data, 0, 0);
//	}
//
//	// �`��X�e�[�g�ݒ�
//	{
//		// Setup viewport
//		D3D11_VIEWPORT viewPort;
//		::memset(&viewPort, 0, sizeof(viewPort));
//		viewPort.Width = drawData->DisplaySize.x;
//		viewPort.Height = drawData->DisplaySize.y;
//		viewPort.MinDepth = 0.0f;
//		viewPort.MaxDepth = 1.0f;
//		viewPort.TopLeftX = viewPort.TopLeftY = 0;
//		context->RSSetViewports(1, &viewPort);
//
//		// �V�F�[�_�[
//		context->VSSetShader(vertexShader.Get(), nullptr, 0);
//		context->PSSetShader(pixelShader.Get(), nullptr, 0);
//		context->VSSetConstantBuffers(0, 1, constantBuffer.GetAddressOf());
//
//		// ���_�o�b�t�@
//		UINT stride = sizeof(ImDrawVert);
//		UINT offset = 0;
//		context->IASetInputLayout(inputLayout.Get());
//		context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
//		context->IASetVertexBuffers(0, 1, vertexBuffer.GetAddressOf(), &stride, &offset);
//		context->IASetIndexBuffer(indexBuffer.Get(), sizeof(ImDrawIdx) == 2 ? DXGI_FORMAT_R16_UINT : DXGI_FORMAT_R32_UINT, 0);
//
//		// �X�e�[�g
//		const float blend_factor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
//		context->OMSetBlendState(blendState.Get(), blend_factor, 0xFFFFFFFF);
//		context->OMSetDepthStencilState(depthStencilState.Get(), 0);
//		context->RSSetState(rasterizerState.Get());
//		context->PSSetSamplers(0, 1, samplerState.GetAddressOf());
//	}
//
//	// ���_�f�[�^�ςݍ���
//	{
//		D3D11_MAPPED_SUBRESOURCE mappedVB, mappedIB;
//		HRESULT hr = context->Map(vertexBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedVB);
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//
//		hr = context->Map(indexBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedIB);
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//
//		ImDrawVert* dstVertex = (ImDrawVert*)mappedVB.pData;
//		ImDrawIdx* dstIndex = (ImDrawIdx*)mappedIB.pData;
//		for (int i = 0; i < drawData->CmdListsCount; ++i)
//		{
//			const ImDrawList* cmdList = drawData->CmdLists[i];
//			::memcpy(dstVertex, cmdList->VtxBuffer.Data, cmdList->VtxBuffer.Size * sizeof(ImDrawVert));
//			::memcpy(dstIndex, cmdList->IdxBuffer.Data, cmdList->IdxBuffer.Size * sizeof(ImDrawIdx));
//
//			dstVertex += cmdList->VtxBuffer.Size;
//			dstIndex += cmdList->IdxBuffer.Size;
//		}
//
//		context->Unmap(vertexBuffer.Get(), 0);
//		context->Unmap(indexBuffer.Get(), 0);
//	}
//
//	// �`��
//	{
//		int globalIdxOffset = 0;
//		int globalVtxOffset = 0;
//		ImVec2 clip_off = drawData->DisplayPos;
//		for (int i = 0; i < drawData->CmdListsCount; ++i)
//		{
//			const ImDrawList* cmdList = drawData->CmdLists[i];
//			for (int cmd_i = 0; cmd_i < cmdList->CmdBuffer.Size; cmd_i++)
//			{
//				const ImDrawCmd* pcmd = &cmdList->CmdBuffer[cmd_i];
//				if (pcmd->UserCallback != NULL)
//				{
//					// User callback, registered via ImDrawList::AddCallback()
//					// (ImDrawCallback_ResetRenderState is a special callback value used by the user to request the renderer to reset render state.)
//					if (pcmd->UserCallback == ImDrawCallback_ResetRenderState)
//					{
//						//SetRenderState(context, drawData);
//					}
//					else
//					{
//						pcmd->UserCallback(cmdList, pcmd);
//					}
//				}
//				else
//				{
//					// Apply scissor/clipping rectangle
//					const D3D11_RECT r = { (LONG)(pcmd->ClipRect.x - clip_off.x), (LONG)(pcmd->ClipRect.y - clip_off.y), (LONG)(pcmd->ClipRect.z - clip_off.x), (LONG)(pcmd->ClipRect.w - clip_off.y) };
//					context->RSSetScissorRects(1, &r);
//
//					// Bind texture, Draw
//					ID3D11ShaderResourceView* srv = (ID3D11ShaderResourceView*)pcmd->TextureId;
//					context->PSSetShaderResources(0, 1, &srv);
//					context->DrawIndexed(pcmd->ElemCount, pcmd->IdxOffset + globalIdxOffset, pcmd->VtxOffset + globalVtxOffset);
//				}
//			}
//			globalIdxOffset += cmdList->IdxBuffer.Size;
//			globalVtxOffset += cmdList->VtxBuffer.Size;
//		}
//		ID3D11ShaderResourceView* nullSRV = nullptr;
//		context->PSSetShaderResources(0, 1, &nullSRV);
//	}
//}
//
//// �`��I��
//void SwordTrajectoryShader::End(ID3D11DeviceContext* dc)
//{
//	dc->VSSetShader(nullptr, nullptr, 0);
//	dc->PSSetShader(nullptr, nullptr, 0);
//	dc->IASetInputLayout(nullptr);
//}

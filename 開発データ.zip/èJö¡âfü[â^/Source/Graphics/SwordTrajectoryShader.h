#pragma once
#include "Misc.h"
#include <memory>
#include <wrl.h>
#include "Graphics/Shader.h"
#include "Graphics/Texture.h"
#include "SwordTrajectory.h"

class SwordTrajectoryShader : public Shader
{
public:
	SwordTrajectoryShader(ID3D11Device* device);
	~SwordTrajectoryShader() override {}

	void Begin(ID3D11DeviceContext* dc, const RenderContext& rc) override;
	void Draw(ID3D11DeviceContext* dc, const Model* model, float dissolveThreshold) override;
	void End(ID3D11DeviceContext* dc) override;

private:
	static const int MaxBones = 128;

	struct ConstantBuffer
	{
		DirectX::XMFLOAT4X4	viewProjection;
	};
    
	Microsoft::WRL::ComPtr<ID3D11Buffer>			constantBuffer;

	Microsoft::WRL::ComPtr<ID3D11VertexShader>		vertexShader;
	Microsoft::WRL::ComPtr<ID3D11PixelShader>		pixelShader;
	Microsoft::WRL::ComPtr<ID3D11InputLayout>		inputLayout;

	Microsoft::WRL::ComPtr<ID3D11BlendState>		blendState;
	Microsoft::WRL::ComPtr<ID3D11RasterizerState>	rasterizerState;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilState>	depthStencilState;

	Microsoft::WRL::ComPtr<ID3D11SamplerState>		samplerState;

	Microsoft::WRL::ComPtr<ID3D11Buffer>				vertexBuffer;
};
#pragma once
#include <memory>
#include <vector>
#include "Graphics/Graphics.h"
#include "Graphics/ExpansionFont.h"
#include <map>
#include <iostream>
#include <functional>


class ExpansionFontManager
{
private:
	inline static std::unique_ptr<ExpansionFontManager> instance = nullptr;

private:
	enum class FontType
	{
		Normal,
		FadeOut,
	};
public:
	ExpansionFontManager();
	~ExpansionFontManager() {};

	static ExpansionFontManager& GetInstance()
	{
		static ExpansionFontManager instance;
		return instance;
	}

	//�Z�b�g
	void SetFont(float x, float y, float scale, float scale_factor, float exist_timer, const wchar_t* string, DirectX::XMFLOAT4 color = DirectX::XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), int type = static_cast<int> (FontType::Normal));
	
	//�X�V����
	void Update(float elapsedTime);
	//�`�揈��
	void Render(ID3D11DeviceContext* dc, Font* font);
	//�폜
	void Remove(ExpansionFont* fonts);
	//�S�폜
	void Clear();

private:
	std::vector<ExpansionFont*> font_array;
	std::vector<ExpansionFont*> remove_array;

	std::unique_ptr<ExpansionFont> font;

	std::map< FontType, void(*)(float x, float y, float scale, float scale_factor, float exist_timer, const wchar_t* string, DirectX::XMFLOAT4 color, int id)> font_type_array;
};
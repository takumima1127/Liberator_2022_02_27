#pragma once
#pragma once
#include <DirectXMath.h>
#include <map>
#include <vector>
#include <memory>
#include <string>

class StateData
{
public:
	StateData() {};
	~StateData() {};
	void Initialize(float cancel_time, int hit_max, float begin_trajectory_time, float end_trajectory_time);
	void CollisionFlagInit();//����t���O������
	enum class StateCollisionFlag
	{
		Before,
		True,
		Affter
	};

private:
};

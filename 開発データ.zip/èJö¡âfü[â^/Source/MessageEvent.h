#pragma once
#include <DirectXMath.h>
#include "Event.h"
#include <map>
#include <vector>

#include <memory>
#include "UI.h"
#include "Graphics/Font.h"

//�~�b�V����
class MessageEvent : public Event
{
public:
	enum class MessageState
	{
		None = -1,
		Message1,
		Message2,
		Message3
	};

public:
	MessageEvent(const wchar_t* window_name, const wchar_t* message, DirectX::XMFLOAT2 window_position, DirectX::XMFLOAT2 window_size, DirectX::XMFLOAT3 position, float scale, XMFLOAT4 color = UI_Window::color_array.at(UI_Window::WindowColor::Default));
	~MessageEvent() {};

	//�j��
	void Destroy();

	void Initialize();
	void Update(float elapsedtime);
	void Render(ID3D11DeviceContext* dc, Font* font);//UI�֌W�\��

private:
	bool is_active;//�C�x���g�����������ǂ���

private:
	//UI�֌W
	std::unique_ptr<UI_Window> window = nullptr;//�X�e�[�^�X�\���p�E�C���h�E

private:
	//�萔
	const  float DELETE_TIMER_MAX = 1.5f;
public:
	bool GetIsActive() { return is_active; }
	void SetIsActive(const bool is_active) { this->is_active = is_active; }
};
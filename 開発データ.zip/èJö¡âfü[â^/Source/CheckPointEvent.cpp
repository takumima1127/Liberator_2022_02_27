#include "CheckPointEvent.h"
#include "CheckPointEventManager.h"

CheckPointEvent::CheckPointEvent(DirectX::XMFLOAT3 position, float scale)
{
	this->position = position;
	this->scale = scale;
	is_finishd = false;
}

void CheckPointEvent::Destroy()
{
	CheckPointEventManager::GetInstance().Remove(this);
}

void CheckPointEvent::Initialize()
{
}

void CheckPointEvent::Update(float elapsedtime)
{
}
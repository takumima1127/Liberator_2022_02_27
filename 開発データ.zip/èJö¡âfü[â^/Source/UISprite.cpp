#include "UI.h"
UI_Sprite::UI_Sprite()
{
	sprite = std::make_unique<Sprite>();
	//texture = std::make_unique<Texture>();
	//texture->Load();
	//texture->Load(L"Data/Sprite/test/test2.jpeg");

	position = XMFLOAT2(.0f, .0f);
	size = XMFLOAT2(.0f, .0f);
	scroll = XMFLOAT2(.0f, .0f);
	float angle = .0f;
	XMFLOAT4 color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
}

UI_Sprite::UI_Sprite(const wchar_t* filename)
{
	sprite = std::make_unique<Sprite>();
	texture = std::make_unique<Texture>();
	texture->Load(filename);
	//texture->Load(L"Data/Sprite/test/test2.jpeg");

	position = XMFLOAT2(.0f, .0f);
	size = XMFLOAT2(.0f, .0f);
	scroll = XMFLOAT2(.0f, .0f);
	float angle = .0f;
	XMFLOAT4 color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
}

UI_Sprite::UI_Sprite(const wchar_t* filename, XMFLOAT2 position, XMFLOAT2 size, XMFLOAT2 scroll, float angle, XMFLOAT4 color)
{
	sprite = std::make_unique<Sprite>();
	texture = std::make_unique<Texture>();
	texture->Load(filename);
	//texture->Load(L"Data/Sprite/test/test2.jpeg");

	this->position = position;
	this->size = size;
	this->scroll = scroll;
	this->angle = angle;
	this->color = color;
}

UI_Sprite::~UI_Sprite()
{
}

void UI_Sprite::Update(float elapsedTime)
{
}

void UI_Sprite::Render(ID3D11DeviceContext* dc)
{
	if (texture != nullptr)
	{
		sprite->Render(
			texture,
			dc,
			position.x,
			position.y,
			size.x * static_cast<float>(texture->GetWidth()),
			size.y * static_cast<float>(texture->GetHeight()),
			scroll.x, scroll.y,//�X�N���[���l
			static_cast<float>(texture->GetWidth()),//�摜�̉���
			static_cast<float>(texture->GetHeight()),//�摜�̏c��
			angle,
			color.x, color.y, color.z, color.w
		);
	}
	else
	{
		sprite->Render(
			dc,
			position.x,
			position.y,
			size.x,
			size.y,
			scroll.x, scroll.y,//�X�N���[���l
			size.x,//�摜�̉���
			size.y,//�摜�̏c��
			angle,
			color.x, color.y, color.z, color.w
		);
	}
}

void UI_Sprite::Render(std::shared_ptr<Texture> tex, ID3D11DeviceContext* dc)
{
	sprite->Render(
		tex,
		dc,
		position.x,
		position.y,
		size.x * static_cast<float>(tex->GetWidth()),
		size.y * static_cast<float>(tex->GetHeight()),
		scroll.x, scroll.y,//�X�N���[���l
		static_cast<float>(tex->GetWidth()),//�摜�̉���
		static_cast<float>(tex->GetHeight()),//�摜�̏c��
		angle,
		color.x, color.y, color.z, color.w
	);
}

void UI_Sprite::Render(ID3D11DeviceContext* dc, XMFLOAT2 position, XMFLOAT2 size, XMFLOAT2 scroll, float angle, XMFLOAT4 color)
{
	if (texture != nullptr)
	{
		sprite->Render(
			texture,
			dc,
			position.x,
			position.y,
			size.x * static_cast<float>(texture->GetWidth()),
			size.y * static_cast<float>(texture->GetHeight()),
			scroll.x, scroll.y,//�X�N���[���l
			static_cast<float>(texture->GetWidth()),//�摜�̉���
			static_cast<float>(texture->GetHeight()),//�摜�̏c��
			angle,
			color.x, color.y, color.z, color.w
		);
	}
	else
	{
		sprite->Render(
			dc,
			position.x,
			position.y,
			size.x,
			size.y,
			scroll.x, scroll.y,//�X�N���[���l
			size.x,//�摜�̉���
			size.y,//�摜�̏c��
			angle,
			color.x, color.y, color.z, color.w
		);
	}
}

void UI_Sprite::Render(std::shared_ptr<Texture> tex, ID3D11DeviceContext* dc, XMFLOAT2 position, XMFLOAT2 size, XMFLOAT2 scroll, float angle, XMFLOAT4 color)
{
	sprite->Render(
		tex,
		dc,
		position.x,
		position.y,
		size.x * static_cast<float>(tex->GetWidth()),
		size.y * static_cast<float>(tex->GetHeight()),
		scroll.x, scroll.y,//�X�N���[���l
		static_cast<float>(tex->GetWidth()),//�摜�̉���
		static_cast<float>(tex->GetHeight()),//�摜�̏c��
		angle,
		color.x, color.y, color.z, color.w
	);
}
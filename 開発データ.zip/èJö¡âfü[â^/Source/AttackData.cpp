#include "AttackData.h"

void AttackData::Initialize(float cancel_time, int hit_max, float begin_trajectory_time, float end_trajectory_time)
{
	this->cancel_time = cancel_time;
	this->hit_max = hit_max;
	this->begin_trajectory_time = begin_trajectory_time;
	this->end_trajectory_time = end_trajectory_time;
	collision_data_array.resize(hit_max);
}
void AttackData::CollisionFlagInit()
{
	for (int i = 0; i < static_cast<int>(collision_data_array.size()); i++)
	{
		//����t���O������
		collision_data_array[i].collision_flag = AttackData::AttackCollisionFlag::Before;
	}
}
void AttackData::SetCollisionDataArraySize(int size)
{
	collision_data_array.resize(size);
}
void AttackData::SetCollisionData(int iterator, int damage, float begin_collision_time, float end_collision_time)
{
	collision_data_array[iterator].damage = damage;
	collision_data_array[iterator].begin_collision_time = begin_collision_time;
	collision_data_array[iterator].end_collision_time = end_collision_time;
}
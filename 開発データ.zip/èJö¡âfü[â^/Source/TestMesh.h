#pragma once

#include <wrl.h>
#include <d3d11.h>
#include <DirectXMath.h>
#include "Graphics/Shader.h"
#include "Graphics/Texture.h"

// �X�v���C�g
class TestMesh
{
public:
	TestMesh();
	TestMesh(const char* filename);
	~TestMesh() {}

	struct Vertex
	{
		DirectX::XMFLOAT3 position = { 0, 0, 0 };
		DirectX::XMFLOAT4 color = {.0f, .0f, .0f, .0f };
		DirectX::XMFLOAT2 texcoord = { 0, 0 };
	};

	//�萔�o�b�t�@
	struct ConstantBuffer
	{
		DirectX::XMFLOAT4X4	viewProjection;
	};

	void Update();
	
	// �`����s
	void Render(ID3D11DeviceContext* dc,
		float dx, float dy,
		float dw, float dh,
		float sx, float sy,
		float sw, float sh,
		float angle,
		float r, float g, float b, float a);

	//TODO �e�N�X�`���������Ɏ����ė����Render()�֐��쐬
	/*void Render(Texture* tex,
		ID3D11DeviceContext* immediate_context,
		float dx, float dy,
		float dw, float dh,
		float sx, float sy,
		float sw, float sh,
		float angle,
		float r, float g, float b, float a) const;*/

	void Render(std::shared_ptr<Texture> tex,
		ID3D11DeviceContext* immediate_context,
		const RenderContext& rc,
		float dx, float dy,
		float dw, float dh,
		float sx, float sy,
		float sw, float sh,
		float angle,
		float r, float g, float b, float a);

	// �e�N�X�`�����擾
	int GetTextureWidth() const { return textureWidth; }

	// �e�N�X�`�������擾
	int GetTextureHeight() const { return textureHeight; }

private:
	Microsoft::WRL::ComPtr<ID3D11VertexShader>			vertexShader;
	Microsoft::WRL::ComPtr<ID3D11PixelShader>			pixelShader;
	Microsoft::WRL::ComPtr<ID3D11InputLayout>			inputLayout;

	Microsoft::WRL::ComPtr<ID3D11Buffer>				vertexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer>				indexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer>				constantBuffer;

	Microsoft::WRL::ComPtr<ID3D11BlendState>			blendState;
	Microsoft::WRL::ComPtr<ID3D11RasterizerState>		rasterizerState;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilState>		depthStencilState;

	Microsoft::WRL::ComPtr<ID3D11SamplerState>			samplerState;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView>	shaderResourceView;

	int textureWidth = 0;
	int textureHeight = 0;

	std::vector<Vertex> vertices;//���_�o�b�t�@
	std::vector<u_int> indices;//�C���f�b�N�X�o�b�t�@

	std::vector<DirectX::XMFLOAT3> position;

	int vertex_size = 8;//���_�o�b�t�@�̑傫��
	int index_size = 18;

	int m_IndexCount;
};
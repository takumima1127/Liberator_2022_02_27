#include "MissionData.h"
#include "FileManager.h"

//MissionData::MissionData(int subjugation_quota, int achievement_count, int timer, std::vector<EnemyData> enemy_data)
//{
//	this->subjugation_quota = subjugation_quota;
//	this->achievement_count = achievement_count;
//	this->timer = timer;
//	this->enemy_data = enemy_data;
//}

MissionData::MissionData()
{
	FileManager& file_manager = FileManager::GetInstance();

	file_data_array.clear();
	file_data_array = file_manager.LoadFileMissionData("Data/Mission/MissionData/data_01.csv");

	//�G�f�[�^�o�^
	data_array.insert(std::make_pair(MissionData::FileState::Data_01, file_data_array.at(static_cast<int>(Mission::MissionState::Mission1))));
	data_array.insert(std::make_pair(MissionData::FileState::Data_02, file_data_array.at(static_cast<int>(Mission::MissionState::Mission2))));
	data_array.insert(std::make_pair(MissionData::FileState::Data_03, file_data_array.at(static_cast<int>(Mission::MissionState::Mission3))));
}

MissionData::SetData MissionData::GetData(int state)
{
	//int state_num = static_cast<int>(state);
	MissionData::FileState file_state = static_cast<MissionData::FileState>(state);
	
	return data_array.at(file_state);
}

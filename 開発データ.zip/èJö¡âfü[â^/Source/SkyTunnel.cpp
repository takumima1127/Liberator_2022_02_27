#include "SkyTunnel.h"
#include <stdio.h> 
#include <WICTextureLoader.h>
#include "Misc.h"
#include "Graphics/Graphics.h"

SkyTunnel::SkyTunnel(std::shared_ptr<Texture> tex, std::shared_ptr<Texture> scroll_tex, DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 scale, DirectX::XMFLOAT2 scroll)
{	
	Tunnel = std::make_unique<TunnelMeshShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f));
	scroll_Tunnel1 = std::make_unique<TunnelMeshScrollShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f), scroll);
	scroll_Tunnel2 = std::make_unique<TunnelMeshScrollShader>(scroll_tex, position, DirectX::XMFLOAT3(scale.x * 1.1f, scale.y * 1.1f, scale.z * 1.1f), scroll);
}

SkyTunnel::SkyTunnel(std::shared_ptr<Texture> tex, std::shared_ptr<Texture> scroll_tex, DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 scale, DirectX::XMFLOAT2 scroll1, DirectX::XMFLOAT2 scroll2)
{
	Tunnel = std::make_unique<TunnelMeshShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f));
	scroll_Tunnel1 = std::make_unique<TunnelMeshScrollShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f), scroll1);
	scroll_Tunnel2 = std::make_unique<TunnelMeshScrollShader>(scroll_tex, position, DirectX::XMFLOAT3(scale.x * 1.1f, scale.y * 1.1f, scale.z * 1.1f), scroll2);
}

void SkyTunnel::Update(float elapsedTime)
{
	scroll_Tunnel1->Update(elapsedTime);
	scroll_Tunnel2->Update(elapsedTime);
}

void SkyTunnel::Render(ID3D11DeviceContext* dc, const RenderContext& rc, float r, float g, float b, float a)
{
#if 0
	Tunnel->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);
	scroll_Tunnel->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);

#else
	scroll_Tunnel2->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);
	scroll_Tunnel1->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);

	//Tunnel->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);

#endif
}
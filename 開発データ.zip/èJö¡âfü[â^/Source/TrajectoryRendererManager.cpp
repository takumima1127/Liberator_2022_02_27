#include "TrajectoryRendererManager.h"
#include "PlayerManager.h"

TrailRendererManager::TrailRendererManager()
{
#if 0
	renderers.clear();
	renderers.resize(3);
	renderers[0] = new TrailRenderer(SWORD_TRAJECTORY_EXIST_MAX, L"Data/Sprite/Trajectory/Sword02.png", PlayerManager::GetInstance()->GetSwordHeadPosition(), PlayerManager::GetInstance()->GetSwordTailPosition());
	renderers[0]->Initialize();
	renderers.emplace_back(renderers[0]);

	renderers[1] = new TrailRenderer(GLIDE_TRAJECTORY_EXIST_MAX, L"Data/Sprite/Trajectory/TrajectoryTest.png", { PlayerManager::GetInstance()->GetLeftToePosition().x, PlayerManager::GetInstance()->GetLeftToePosition().y + 0.1f, PlayerManager::GetInstance()->GetLeftToePosition().z }, PlayerManager::GetInstance()->GetLeftToePosition());
	renderers[1]->Initialize();
	renderers.emplace_back(renderers[1]);

	renderers[2] = new TrailRenderer(GLIDE_TRAJECTORY_EXIST_MAX, L"Data/Sprite/Trajectory/TrajectoryTest.png", { PlayerManager::GetInstance()->GetRightToePosition().x, PlayerManager::GetInstance()->GetRightToePosition().y + 0.1f, PlayerManager::GetInstance()->GetRightToePosition().z }, PlayerManager::GetInstance()->GetRightToePosition());
	renderers[2]->Initialize();
	renderers.emplace_back(renderers[2]);
	
	//renderers.emplace_back(L"Data/Sprite/test/test2.jpeg");
	//renderers.emplace_back(L"Data/Sprite/test/test.jpg");
	//renderers.emplace_back(L"Data/Sprite/test/test.jpg");
#else
	renderers.clear();//�z�񏉊���

	trail_renderer = std::make_unique<TrailRenderer>(SWORD_TRAJECTORY_EXIST_MAX, L"Data/Sprite/Trajectory/Sword02.png", PlayerManager::GetInstance()->GetSwordHeadPosition(), PlayerManager::GetInstance()->GetSwordTailPosition());
	trail_renderer->Initialize();
	renderers.emplace_back(std::move(trail_renderer.get()));
	trail_renderer.release();

	trail_renderer = std::make_unique<TrailRenderer>(GLIDE_TRAJECTORY_EXIST_MAX, L"Data/Sprite/Trajectory/TrajectoryTest.png", DirectX::XMFLOAT3(PlayerManager::GetInstance()->GetLeftToePosition().x, PlayerManager::GetInstance()->GetLeftToePosition().y + 0.1f, PlayerManager::GetInstance()->GetLeftToePosition().z ), PlayerManager::GetInstance()->GetLeftToePosition());
	trail_renderer->Initialize();
	renderers.emplace_back(std::move(trail_renderer.get()));
	trail_renderer.release();

	trail_renderer = std::make_unique<TrailRenderer>(GLIDE_TRAJECTORY_EXIST_MAX, L"Data/Sprite/Trajectory/TrajectoryTest.png",  DirectX::XMFLOAT3(PlayerManager::GetInstance()->GetRightToePosition().x, PlayerManager::GetInstance()->GetRightToePosition().y + 0.1f, PlayerManager::GetInstance()->GetRightToePosition().z ), PlayerManager::GetInstance()->GetRightToePosition());
	trail_renderer->Initialize();
	renderers.emplace_back(std::move(trail_renderer.get()));
	trail_renderer.release();

#endif
}

void TrailRendererManager::Initialize()
{
	//renderers[0]->Initialize(L"Data/Sprite/test/test2.jpeg");
}

void TrailRendererManager::Update()
{
	renderers[0]->Update(PlayerManager::GetInstance()->GetSwordHeadPosition(), PlayerManager::GetInstance()->GetSwordTailPosition(), PlayerManager::GetInstance()->GetTrajectorySwordFlag(), true);
	renderers[1]->Update({ PlayerManager::GetInstance()->GetLeftToePosition().x, PlayerManager::GetInstance()->GetLeftToePosition().y + 0.1f, PlayerManager::GetInstance()->GetLeftToePosition().z }, PlayerManager::GetInstance()->GetLeftToePosition(), PlayerManager::GetInstance()->GetTrajectoryToeFlag(), false);
	renderers[2]->Update({ PlayerManager::GetInstance()->GetRightToePosition().x, PlayerManager::GetInstance()->GetRightToePosition().y + 0.1f, PlayerManager::GetInstance()->GetRightToePosition().z }, PlayerManager::GetInstance()->GetRightToePosition(), PlayerManager::GetInstance()->GetTrajectoryToeFlag(), false);
}

void TrailRendererManager::Render(ID3D11DeviceContext* dc, const RenderContext& rc)
{
	////���̋O��
	//if (PlayerManager::GetInstance()->GetTrajectorySword())
	{
		renderers[0]->Render(dc, rc,
			1.0f, 1.0f, 1.0f, 1.0f);
	}
	//
	//////�ܐ�̋O��
#if 0
	{
		renderers[1]->Render(dc, rc, 10, 10,
			0.0f,
			0.0f,
			.0f, .0f,
			.0f,
			1.0f, 1.0f, 1.0f, 1.0f);
		
		renderers[2]->Render(dc, rc, 10, 10,
			0.0f,
			0.0f,
			.0f, .0f,
			.0f,
			1.0f, 1.0f, 1.0f, 1.0f);
	}
#else
	{
		renderers[1]->Render(dc, rc, PlayerManager::GetInstance()->GetTrajectoryToeFlag(),
			10, 10,
			0.0f,
			0.0f,
			.0f, .0f,
			.0f,
			1.0f, 1.0f, 1.0f, 1.0f);
	
		renderers[2]->Render(dc, rc, PlayerManager::GetInstance()->GetTrajectoryToeFlag(),
			10, 10,
			0.0f,
			0.0f,
			.0f, .0f,
			.0f,
			1.0f, 1.0f, 1.0f, 1.0f);
	}
#endif
}

void TrailRendererManager::Clear()
{
#if 0
	delete renderers[0];
	delete renderers[1];
	delete renderers[2];

	renderers.clear();

#else
	for (TrailRenderer* renderer : renderers)
	{
		delete renderer;
	}
	renderers.clear();
#endif
}

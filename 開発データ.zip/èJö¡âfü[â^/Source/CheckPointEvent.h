#pragma once
#pragma once
#include <DirectXMath.h>
#include "Event.h"
#include <map>
#include <vector>

#include <memory>
#include "UI.h"
#include "Graphics/Font.h"

//�~�b�V����
class CheckPointEvent : public Event
{
public:
	CheckPointEvent(DirectX::XMFLOAT3 position, float scale);
	~CheckPointEvent() {};
	//�j��
	void Destroy();

	void Initialize();
	void Update(float elapsedtime);//
};
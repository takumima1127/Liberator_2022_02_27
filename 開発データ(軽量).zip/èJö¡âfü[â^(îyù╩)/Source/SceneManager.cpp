#include "SceneManager.h"
#include "SceneTitle.h"
#include "SceneGame.h"
#include "SceneLoading.h"

void ChangeSceneTitle()
{
	SceneManager::Instance().ChangeScene(new SceneLoading(new SceneTitle));
}

void ChangeSceneGame()
{
	SceneManager::Instance().ChangeScene(new SceneLoading(new SceneGame));
}

SceneManager::SceneManager()
{
	scene_array =
	{
		{SceneType::Title, ChangeSceneTitle},
		{SceneType::Game, ChangeSceneGame}
	};
}

//�X�V����
void SceneManager::Update(float elapsedTime)
{
	if (currentScene != nullptr)
	{
		currentScene->Update(elapsedTime);
	}
}

//�`�揈��
void SceneManager::Render()
{
	if (currentScene != nullptr)
	{
		currentScene->Render();
	}
}

//�V�[���N���A
void SceneManager::Clear()
{
	if (currentScene != nullptr)
	{
		currentScene->Finalize();
		delete currentScene;
		currentScene = nullptr;
	}
}

//�V�[���؂�ւ�
void SceneManager::ChangeScene(SceneType scene_type)
{
	//scene_array.at(scene_type);
	scene_array[scene_type]();
}

//�V�[���؂�ւ�
void SceneManager::ChangeScene(Scene* scene)
{
	//�Â��V�[�����I������
	Clear();

	//�V�����V�[����ݒ�
	currentScene = scene;

	//�V�[��������
	if (!currentScene->IsReady())
	{
		currentScene->Initialize();
	}
}

void SceneManager::SetScene(SceneType scene_id)
{
	currentScene->SetScene(static_cast<int>(scene_id));
}

Scene::FilterFlag SceneManager::GetFilterFlag()
{
	return currentScene->GetFilterFlag();
}

void SceneManager::SetFilterFlag(Scene::FilterFlag filter_flag)
{
	currentScene->SetFilterFlag(filter_flag);
}

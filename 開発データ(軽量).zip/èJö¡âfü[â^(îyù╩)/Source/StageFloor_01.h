#pragma once
#include "Graphics/Model.h"
#include "Stage.h"

//�X�e�[�W
class StageFloor_01 : public Stage
{
public:
	StageFloor_01();
	~StageFloor_01() override;

	//����������
	void Initialize(DirectX::XMFLOAT3 position = DirectX::XMFLOAT3(.0f, .0f, .0f), DirectX::XMFLOAT3 angle = DirectX::XMFLOAT3(.0f, .0f, .0f), DirectX::XMFLOAT3 scale = DirectX::XMFLOAT3(0.02f, 0.02f, 0.02f)) override;

	//�X�V����
	void Update(float elapsedTime) override;

	//�`�揈��
	void Render(ID3D11DeviceContext* dc, Shader* shader) override;

	//���C�L���X�g
	bool RayCast(const DirectX::XMFLOAT3& start, const DirectX::XMFLOAT3& end, HitResult& hit) override;

private:
	Model* model = nullptr;

public:
	DirectX::XMFLOAT3 resize_scale = DirectX::XMFLOAT3(0.02f, 0.02f, 0.02f);//���T�C�Y�p�ϐ�
};
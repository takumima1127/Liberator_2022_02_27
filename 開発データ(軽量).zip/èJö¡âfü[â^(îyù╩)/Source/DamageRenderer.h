#pragma once
#include <memory>
#include <vector>
#include "Graphics/Graphics.h"
#include "DamageData.h"

class DamageRenderer
{
private:
    inline static std::unique_ptr<DamageRenderer> instance = nullptr;

public:
    DamageRenderer();
    ~DamageRenderer();

    static DamageRenderer& Instance()
    {
        static DamageRenderer instance;
        return instance;
    }

    //�Z�b�g
    void Set(int damage, DirectX::XMFLOAT3 position, int exist_timer = EXIST_TIMER_MAX);

    //�X�V����
    void Update(float elapsedTime);

    //�`�揈��
    void Render(ID3D11DeviceContext* dc, Font* font, const DirectX::XMFLOAT4X4& view, const DirectX::XMFLOAT4X4& projection);
    
    //�폜
    void Remove(DamageData* d);
    
    //�S�폜
    void Clear();

private:
    //�萔
    static const  int EXIST_TIMER_MAX = 100;

private:
    std::vector<DamageData*> data;//TODO array�ɖ����ύX
    std::vector<DamageData*> removes;

    //std::vector<std::unique_ptr<DamageData>> data;

    //DamageData* d_data = nullptr;
    std::unique_ptr<DamageData> d_data;
};
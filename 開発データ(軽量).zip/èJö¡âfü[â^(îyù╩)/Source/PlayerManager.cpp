#include "PlayerManager.h"

void PlayerManager::Initialize()
{
	GetInstance()->Initialize();
}

void PlayerManager::Update(float elapsedTime)
{
	GetInstance()->Update(elapsedTime);
}

void PlayerManager::Render(ID3D11DeviceContext* dc, Shader* shader)
{
	GetInstance()->Render(dc, shader);
}

void PlayerManager::DrawDebugPrimitive()
{
	GetInstance()->DrawDebugPrimitive();
}
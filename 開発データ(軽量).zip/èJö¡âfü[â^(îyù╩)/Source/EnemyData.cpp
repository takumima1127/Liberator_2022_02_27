#include "EnemyData.h"
#include "FileManager.h"


EnemyData::EnemyData()
{
	////�t�@�C�����o�^
	//file_name_array.insert(std::make_pair(FileState::Data_01, "Data/Mission/EnemyData/data_01.csv"));
	//file_name_array.insert(std::make_pair(FileState::Data_02, "Data/Mission/EnemyData/data_02.csv"));
	//file_name_array.insert(std::make_pair(FileState::Data_03, "Data/Mission/EnemyData/data_03.csv"));

	FileManager& file_manager = FileManager::GetInstance();

	//�G�f�[�^�o�^
	data_array.insert(std::make_pair(EnemyData::FileState::Data_01, file_manager.LoadFileEnemyData("Data/Mission/EnemyData/data_01.csv")));
	data_array.insert(std::make_pair(EnemyData::FileState::Data_02, file_manager.LoadFileEnemyData("Data/Mission/EnemyData/data_02.csv")));
	data_array.insert(std::make_pair(EnemyData::FileState::Data_03, file_manager.LoadFileEnemyData("Data/Mission/EnemyData/data_03.csv")));
}

std::vector<EnemyData::SetData> EnemyData::GetDataArray(int state)
{
	EnemyData::FileState file_state = static_cast<EnemyData::FileState>(state);

	return data_array.at(file_state);
}


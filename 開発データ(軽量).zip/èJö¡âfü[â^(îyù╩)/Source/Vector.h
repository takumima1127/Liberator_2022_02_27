#pragma once
#include <iostream>
#include <directxmath.h>

class MyFloat3
{
public:
	//���Z
	inline DirectX::XMFLOAT3 static const Add(DirectX::XMFLOAT3 a, DirectX::XMFLOAT3 b)
	{
		a.x += b.x;
		a.y += b.y;
		a.z += b.z;
		return a;
	}
	//���Z
	inline DirectX::XMFLOAT3 static const Subtract(DirectX::XMFLOAT3 a, DirectX::XMFLOAT3 b)
	{
		a.x -= b.x;
		a.y -= b.y;
		a.z -= b.z;
		return a;
	}
	//��Z
	inline DirectX::XMFLOAT3 static const Multiply(DirectX::XMFLOAT3 a, DirectX::XMFLOAT3 b)
	{
		a.x *= b.x;
		a.y *= b.y;
		a.z *= b.z;
		return a;
	}
	//���Z
	inline DirectX::XMFLOAT3 static const Divide(DirectX::XMFLOAT3 a, DirectX::XMFLOAT3 b)
	{
		a.x /= b.x;
		a.y /= b.y;
		a.z /= b.z;
		return a;
	}

	//���K��
	inline DirectX::XMFLOAT3 static const Normalize(DirectX::XMFLOAT3 a)
	{
		//vector�ɕϊ�
		DirectX::XMVECTOR vector = DirectX::XMLoadFloat3(&a);

		//���K��
		vector = DirectX::XMVector3Normalize(vector);

		//���K�����ꂽ�x�N�g���������ɑ��
		DirectX::XMStoreFloat3(&a, vector);

		return a;
	}

	//�x�N�g���̑傫���擾
	inline float static const Length(DirectX::XMFLOAT3 a)
	{
		//vector�ɕϊ�
		DirectX::XMVECTOR vector = DirectX::XMLoadFloat3(&a);

		//�x�N�g���̒����擾
		vector = DirectX::XMVector3Length(vector);

		//���K�����ꂽ�x�N�g���������ɑ��
		DirectX::XMStoreFloat3(&a, vector);


		float length = a.x;

		return length;
	}
};

class Matrix
{
public:
	//float4x4��Matrix�ϊ�
	inline DirectX::XMMATRIX static const Float4x4ToMatrix(DirectX::XMFLOAT4X4 a)
	{
		DirectX::XMMATRIX A;

		A = XMLoadFloat4x4(&a);
		return A;
	}

	////��Z
	//inline XMMATRIX static const Multiply(XMFLOAT4X4 a, XMFLOAT4X4 b)
	//{
	//	XMMATRIX A, B;
	//	
	//	A = XMLoadFloat4x4(&a);
	//	B = XMLoadFloat4x4(&b);

	//	A *= B;
	//	return A;
	//}
};

class MyVector3 : public MyFloat3
{
public:
	//���Z
	inline DirectX::XMVECTOR static const Divide(DirectX::XMVECTOR a, DirectX::XMVECTOR b)
	{
		DirectX::XMFLOAT3 A, B;
		XMStoreFloat3(&A, a);
		XMStoreFloat3(&B, b);

		return XMLoadFloat3(&(MyFloat3::Divide(A, B)));
	}
};
#include "EnemyManager.h"
#include "Collision.h"
#include "imgui.h"

void SetSlime(DirectX::XMFLOAT3 territory_position, float territory_scale, DirectX::XMFLOAT3 position, float angle, int mission_element)
{
	EnemyManager& enemyManager = EnemyManager::Instance();

	EnemySlime* slime = new EnemySlime();
	slime->SetPosition(DirectX::XMFLOAT3(territory_position.x + position.x, territory_position.y + position.y, territory_position.z + position.z));
	slime->SetAngle(DirectX::XMFLOAT3(.0f, DirectX::XMConvertToRadians(angle), .0f));
	slime->SetTerritory(territory_position, territory_scale);
	slime->SetMissionElement(mission_element);
	slime->SetDissolveThreshold(1.0f);
	enemyManager.Register(slime);
}
void SetMutant(DirectX::XMFLOAT3 territory_position, float territory_scale, DirectX::XMFLOAT3 position, float angle, int mission_element)
{
	EnemyManager& enemyManager = EnemyManager::Instance();
	
	EnemyMutant* mutant = new EnemyMutant();
    mutant->SetPosition(DirectX::XMFLOAT3(territory_position.x + position.x, territory_position.y + position.y, territory_position.z + position.z));
    mutant->SetAngle(DirectX::XMFLOAT3(.0f, DirectX::XMConvertToRadians(angle), .0f));
    mutant->SetTerritory(territory_position, territory_scale);
	mutant->SetMissionElement(mission_element);
	mutant->SetDissolveThreshold(1.0f);
	enemyManager.Register(mutant);
}

void EnemyManager::Register(Enemy* enemy)
{
	enemies.emplace_back(enemy);
}


void EnemyManager::Initialize()
{
#if 0
	enemy_type_array =
	{
		{"Slime", SetSlime},
		{"Mutant", SetMutant},
	};
#else
	enemy_type_array =
	{
		{EnemyType::Slime, SetSlime},
		{EnemyType::Mutant, SetMutant},
	};

#endif
}

//�X�V����
void EnemyManager::Update(float elapsedTime)
{
	for (Enemy* enemy : enemies)
	{
		if (enemy->GetExist())
		{
			enemy->Update(elapsedTime);//�X�V����
			enemy->SubDissolveThreshold(0.01f);
		}
	}


	//�j������
	//��enemies�͈̔�for������erase()����ƕs����������Ă��܂��̂ŁA
	// �X�V�������I�������ɔj�����X�g�ɐς܂ꂽ�I�u�W�F�N�g���폜����B
	for (Enemy* enemy : removes)
	{
		//std::vector����v�f���폜����ꍇ�̓C�e���[�^�[�ō폜���Ȃ���΂Ȃ�Ȃ�
		std::vector<Enemy*>::iterator it = std::find(enemies.begin(), enemies.end(),
			enemy);

		if (it != enemies.end())
		{
			enemies.erase(it);
		}

		//�e�ۂ̔j������
		delete enemy;
	}
	//�j�����X�g���N���A
	removes.clear();

	CollisionEnemyVsEnemies();//�G�ƓG�̓����蔻��
}

//�`�揈��
void EnemyManager::Render(ID3D11DeviceContext* dc, Shader* shader)
{
	for (Enemy* enemy : enemies)
	{
		if (enemy->GetExist())
		{
			enemy->Render(dc, shader);
		}
	}
}

void EnemyManager::Remove(Enemy* enemy)
{
	//�j�����X�g�ɒǉ�
	removes.emplace_back(enemy);
}

void EnemyManager::Clear()
{
	for (Enemy* enemy : enemies)
	{
		delete enemy;
	}
	enemies.clear();
	removes.clear();
}

void EnemyManager::DrawDebugPrimitive()
{
	for (Enemy* enemy : enemies)
	{
		enemy->DrawDebugPrimitive();
	}
}

void EnemyManager::DrawDebugGUI()
{
	for (Enemy* enemy : enemies)
	{
		enemy->DrawDebugGUI();
	}
}

void EnemyManager::CollisionEnemyVsEnemies()
{
	//�S�Ă̓G�Ƒ�������ŏՓ˔���
	for (int i = 0; i < enemies.size(); i++)
	{
		Enemy* enemyA = enemies.at(i);
		for (int j = i + 1; j < enemies.size(); ++j)
		{
			Enemy* enemyB = enemies.at(j);
			//�Փˏ���
			DirectX::XMFLOAT3 outPosition;
			
			////��VS��
			//if (Collision::IntersectSphereVsSphere(
			//	enemyA->GetPosition(),
			//	enemyA->GetRadius(),
			//	enemyB->GetPosition(),
			//	enemyB->GetRadius(),
			//	outPosition)
			//)
			//{
			//	//�����o����̈ʒu����
			//	enemyB->SetPosition(outPosition);
			//}

			if (Collision::IntersectCylinderVsCylinder(
				enemyA->GetPosition(),
				enemyA->GetRadius(),
				enemyA->GetHeight(),
				enemyB->GetPosition(),
				enemyB->GetRadius(),
				enemyB->GetHeight(),
				outPosition
			))
			{
				//����������̈ʒu����
				enemyB->SetPosition(outPosition);
			}
		}
	}
}

//void EnemyManager::SetSlime(DirectX::XMFLOAT3 territory_position, float territory_scale, DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 angle)
//{
//}
//
//void EnemyManager::SetMutant(DirectX::XMFLOAT3 territory_position, float territory_scale, DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 angle)
//{
//	EnemyMutant* mutant = new EnemyMutant();
//	mutant->SetPosition(DirectX::XMFLOAT3(territory_position.x + position.x, territory_position.y + position.y, territory_position.z + position.z));
//	mutant->SetAngle(DirectX::XMFLOAT3(DirectX::XMConvertToRadians(angle.x), DirectX::XMConvertToRadians(angle.y), DirectX::XMConvertToRadians(angle.z)));
//	mutant->SetTerritory(territory_position, territory_scale);
//	Register(mutant);
//}

void EnemyManager::SetEnemy(DirectX::XMFLOAT3 territory_position, float territory_scale, DirectX::XMFLOAT3 position, float angle, int enemy_type, int mission_element)
{
	//�G�l�~�[�z�u
#if 0
	enemy_type_array["Mutant"](territory_position, territory_scale, position, angle, mission_element);

#else
	enemy_type_array[static_cast<EnemyType>(enemy_type)](territory_position, territory_scale, position, angle, mission_element);

#endif

	//EnemyMutant* mutant = new EnemyMutant();
	//mutant->SetPosition(DirectX::XMFLOAT3(territory_position.x + position.x, territory_position.y + position.y, territory_position.z + position.z));
	//mutant->SetAngle(DirectX::XMFLOAT3(DirectX::XMConvertToRadians(angle.x), DirectX::XMConvertToRadians(angle.y), DirectX::XMConvertToRadians(angle.z)));
	//mutant->SetTerritory(territory_position, territory_scale);
    //Register(mutant);
}

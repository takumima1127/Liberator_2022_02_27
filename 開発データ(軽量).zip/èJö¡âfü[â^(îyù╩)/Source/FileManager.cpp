#include "FileManager.h"
#include <DirectXMath.h>

FileManager::FileManager()
{
}

std::vector<EnemyData::SetData> FileManager::LoadFileEnemyData(const char* file_name)
{
    std::vector<EnemyData::SetData> enemy_array;//�G�f�[�^�i�[�p�R���e�i

    std::ifstream ifs(file_name);
    std::string line;
    while (getline(ifs, line)) {
        std::vector<std::string> strvec = split(line, ',');
        
#if 0
        for (int j = 0; j < strvec.size(); j += 6) {
            DirectX::XMFLOAT3 position = DirectX::XMFLOAT3(stof(strvec.at(j)), stof(strvec.at(j + 1)), stof(strvec.at(j + 2)));
            float angle = stof(strvec.at(j + 3));
            int mission_element = stoi(strvec.at(j + 4));//�~�b�V�����̑���
            int enemy_type = stoi(strvec.at(j + 5));//�G�̎��
            EnemyData::SetData set_data = { position, angle, mission_element, enemy_type };//�ǂݍ��񂾏����i�[
            enemy_array.emplace_back(set_data);//�i�[���������R���e�i�֒ǉ�
    }
#else
        for (int j = 0; j < strvec.size(); j += 5) {
            DirectX::XMFLOAT3 position = DirectX::XMFLOAT3(stof(strvec.at(j)), stof(strvec.at(j + 1)), stof(strvec.at(j + 2)));
            float angle = stof(strvec.at(j + 3));
            int enemy_type = stoi(strvec.at(j + 4));//�G�̎��
            EnemyData::SetData set_data = { position, angle, enemy_type };//�ǂݍ��񂾏����i�[
            enemy_array.emplace_back(set_data);//�i�[���������R���e�i�֒ǉ�
        }

#endif
    }
    return enemy_array;
}

std::vector<MissionData::SetData> FileManager::LoadFileMissionData(const char* file_name)
{
    std::vector<MissionData::SetData> mission_array;//�G�f�[�^�i�[�p�R���e�i

    std::ifstream ifs(file_name);
    std::string line;
    while (getline(ifs, line)) {
        std::vector<std::string> strvec = split(line, ',');
        for (int j = 0; j < strvec.size(); j += 2) {
            int subjugation_quota = stoi(strvec.at(j));
            int timer = stoi(strvec.at(j + 1));
            MissionData::SetData set_data = { subjugation_quota, timer };//�ǂݍ��񂾏����i�[
            mission_array.emplace_back(set_data);//�i�[���������R���e�i�֒ǉ�
        }
    }
    return mission_array;
}

std::vector<std::string> FileManager::split(std::string& input, char delimiter)
{
    std::istringstream stream(input);
    std::string field;
    std::vector<std::string> result;
    while (getline(stream, field, delimiter)) {
        result.push_back(field);
    }
    return result;
}

#include "Event.h"

void Event::Initialize()
{
}

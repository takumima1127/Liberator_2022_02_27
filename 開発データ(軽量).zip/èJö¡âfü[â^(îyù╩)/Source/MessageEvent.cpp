#include "MessageEvent.h"

MessageEvent::MessageEvent(const wchar_t* window_name, const wchar_t* message, DirectX::XMFLOAT2 window_position, DirectX::XMFLOAT2 window_size, DirectX::XMFLOAT3 position, float scale, XMFLOAT4 color)
{
	//�C�x���g�p�ϐ�
	this->position = position;
	this->scale = scale;
	is_finishd = false;
	is_active = false;


	//UI�p�ϐ�
	window = std::make_unique<UI_Window>(window_name, window_position, window_size);
	window->AddMessage(message, DirectX::XMFLOAT2(16.0f, 10.0f), window->GetDefaultFontSize());
}

void MessageEvent::Destroy()
{
	//���g���폜(���b�Z�[�W�폜��)
	//MessageEventManager::GetInstance().Remove(this);
}

void MessageEvent::Initialize()
{
}

void MessageEvent::Update(float elapsedtime)
{
	if (is_finishd)
	{
		Destroy();//�폜
	}
}

void MessageEvent::Render(ID3D11DeviceContext* dc, Font* font)
{
	if (is_active)
	{
		//�E�C���h�E�\��
		window->Render(dc, font);
	}
}
